#!/bin/sh -

#MOJO_LOG_LEVEL=1
morbo -w public -w lib -w templates  -v script/test_data_tables 
